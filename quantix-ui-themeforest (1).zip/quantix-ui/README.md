# Quantix UI — AI SaaS Admin Dashboard

> Premium React admin dashboard template for AI-powered SaaS platforms.  
> Built with Vite, React Router v6, and Recharts. No paid dependencies.

---

## Demo Login

| Field    | Value               |
|----------|---------------------|
| Email    | admin@quantix.io    |
| Password | admin123            |

---

## Installation

**Requirements:** Node.js 18+ and npm 9+

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```

Open **http://localhost:5173** in your browser and log in with the demo credentials above.

---

## Build

```bash
# Production build → outputs to /dist
npm run build

# Preview the production build locally
npm run preview
```

---

## Project Structure

```
quantix-ui/
├── index.html                  # HTML entry point
├── vite.config.js              # Vite configuration
├── package.json
├── README.md
├── documentation/
│   └── index.html              # Full HTML documentation
└── src/
    ├── main.jsx                # ReactDOM entry point
    ├── App.jsx                 # Root component + route definitions
    ├── styles/
    │   └── globals.css         # CSS variables, base styles, utilities
    ├── data/
    │   └── mockData.js         # All mock/sample data — replace with your API
    ├── hooks/
    │   ├── useAuth.js          # Authentication (login, logout, session)
    │   ├── useToast.js         # Toast notification system
    │   └── useTheme.js         # Dark / light mode with localStorage
    ├── router/
    │   └── guards.jsx          # ProtectedRoute + PublicRoute components
    ├── components/
    │   ├── layout/
    │   │   ├── AppLayout.jsx   # Shell — sidebar + header + <Outlet>
    │   │   ├── Sidebar.jsx     # Collapsible navigation sidebar
    │   │   └── Header.jsx      # Top bar — search, theme, notifications
    │   ├── ui/
    │   │   ├── KPICard.jsx     # Metric card with value, trend, icon
    │   │   ├── Badge.jsx       # Status badge
    │   │   ├── Modal.jsx       # Accessible modal dialog
    │   │   └── ToastContainer.jsx
    │   └── charts/
    │       └── ChartCard.jsx   # Card wrapper for Recharts charts
    └── pages/
        ├── LoginPage.jsx
        ├── RegisterPage.jsx
        ├── ForgotPasswordPage.jsx
        ├── DashboardPage.jsx
        ├── AnalyticsPage.jsx
        ├── CRMPage.jsx
        ├── FinancePage.jsx
        ├── ProjectsPage.jsx
        ├── KanbanPage.jsx
        ├── CalendarPage.jsx
        ├── ChatPage.jsx
        ├── EmailPage.jsx
        └── SettingsPage.jsx
```

---

## Customization

### Change brand colors

All colors are CSS custom properties in `src/styles/globals.css`:

```css
:root {
  --accent:  #6366f1;   /* Primary brand color  */
  --accent2: #8b5cf6;   /* Secondary            */
  --accent3: #06b6d4;   /* Tertiary accent       */
  --green:   #10b981;
  --red:     #ef4444;
  --orange:  #f59e0b;
}
```

Change any value and both dark and light modes update automatically.

### Connect a real backend

All sample data is in `src/data/mockData.js`. To swap out authentication, edit the `login()` function in `src/hooks/useAuth.js`:

```js
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
const data = await response.json();
if (data.token) {
  localStorage.setItem('qx_session', JSON.stringify(data.user));
  setSession(data.user);
  return { success: true };
}
```

### Add a new page

```jsx
// 1. Create src/pages/MyPage.jsx
export default function MyPage({ toast }) {
  return <div className="page-title">My Page</div>;
}

// 2. Add route in src/App.jsx (inside the protected group):
<Route path="/my-page" element={<MyPage toast={toast} />} />

// 3. Add nav item in src/components/layout/Sidebar.jsx:
{ path: '/my-page', label: 'My Page', icon: '📄' }
```

---

## Dependencies

| Package              | Version | Purpose                |
|----------------------|---------|------------------------|
| react                | 18.2    | UI framework           |
| react-dom            | 18.2    | DOM renderer           |
| react-router-dom     | 6.22    | Client-side routing    |
| recharts             | 2.10    | Chart components       |
| vite                 | 5.x     | Build tool & dev server |
| @vitejs/plugin-react | 4.x     | React Vite plugin      |

All dependencies are open-source with MIT licenses.

---

## Documentation

Open `documentation/index.html` in any browser for the full guide — including component API reference, hook usage, and customization examples.

---

## License

MIT — see `package.json` for details.
