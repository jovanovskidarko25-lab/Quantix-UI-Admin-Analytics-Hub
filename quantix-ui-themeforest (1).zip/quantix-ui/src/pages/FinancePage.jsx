import { useState } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import KPICard from '../components/ui/KPICard';
import ChartCard from '../components/charts/ChartCard';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import { revenueData, initialInvoices, formatCurrency, generateId } from '../data/mockData';

const PIE_DATA = [
  { name: 'Paid', value: 3, color: 'var(--green)' },
  { name: 'Pending', value: 1, color: 'var(--orange)' },
  { name: 'Overdue', value: 1, color: 'var(--red)' },
];

const statusVariant = { Paid: 'paid', Pending: 'pending', Overdue: 'overdue', Draft: 'draft' };

const PER = 4;

export default function FinancePage({ toast }) {
  const [invoices, setInvoices] = useState(initialInvoices);
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ client: '', amount: '', status: 'Draft', date: '' });
  const [errors, setErrors] = useState({});

  const update = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = () => {
    const errs = {};
    if (!form.client.trim()) errs.client = 'Client name required';
    if (!form.amount || isNaN(+form.amount) || +form.amount <= 0) errs.amount = 'Enter a valid amount';
    return errs;
  };

  const addInvoice = () => {
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    const nextNum = String(invoices.length + 1).padStart(3, '0');
    const dateLabel = form.date
      ? new Date(form.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      : new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    setInvoices((prev) => [...prev, { id: `INV-${nextNum}`, client: form.client, amount: +form.amount, status: form.status, date: dateLabel }]);
    setShowModal(false);
    setForm({ client: '', amount: '', status: 'Draft', date: '' });
    setErrors({});
    toast('Invoice created!');
  };

  const paged = invoices.slice((page - 1) * PER, page * PER);
  const pages = Math.ceil(invoices.length / PER);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Finance</div>
          <div className="page-subtitle">Revenue & invoice management</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Invoice</button>
      </div>

      <div className="grid-4 section-gap">
        {[
          { label: 'MRR', value: '$68,400', change: '+12%', trend: 'up', accent: 'purple' },
          { label: 'ARR', value: '$820,800', change: '+18%', trend: 'up', accent: 'green' },
          { label: 'Outstanding', value: '$28,550', change: '+5%', trend: 'down', accent: 'orange' },
          { label: 'Expenses', value: '$41,200', change: '-3%', trend: 'up', accent: 'cyan' },
        ].map((k) => <KPICard key={k.label} {...k} />)}
      </div>

      <div className="grid-2 section-gap">
        <ChartCard title="Monthly Revenue vs Expenses" height={220}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={revenueData} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}K`} />
              <Tooltip contentStyle={{ background: 'var(--bg2)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} formatter={(v) => `$${v.toLocaleString()}`} />
              <Bar dataKey="revenue" fill="var(--accent)" radius={[4, 4, 0, 0]} name="Revenue" />
              <Bar dataKey="expenses" fill="var(--bg4)" radius={[4, 4, 0, 0]} name="Expenses" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Invoice Status" height={220}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={PIE_DATA} cx="50%" cy="50%" outerRadius={80} dataKey="value">
                {PIE_DATA.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: 'var(--bg2)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="card">
        <div className="card-title mb-3">Invoices</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Client</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {paged.map((inv) => (
                <tr key={inv.id}>
                  <td style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{inv.id}</td>
                  <td style={{ fontWeight: 500 }}>{inv.client}</td>
                  <td style={{ fontWeight: 700 }}>{formatCurrency(inv.amount)}</td>
                  <td><Badge variant={statusVariant[inv.status] ?? 'medium'}>{inv.status}</Badge></td>
                  <td className="text-sm text-muted">{inv.date}</td>
                  <td><button className="btn btn-ghost btn-xs">View</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-3" style={{ paddingTop: 12, borderTop: '1px solid var(--border)' }}>
          <span className="text-sm text-muted">Showing {Math.min((page - 1) * PER + 1, invoices.length)}–{Math.min(page * PER, invoices.length)} of {invoices.length}</span>
          <div className="flex gap-2">
            <button className="btn btn-secondary btn-sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>←</button>
            <button className="btn btn-secondary btn-sm" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>→</button>
          </div>
        </div>
      </div>

      <Modal
        open={showModal}
        onClose={() => { setShowModal(false); setErrors({}); }}
        title="🧾 New Invoice"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addInvoice}>Create Invoice</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Client Name *</label>
          <input className="form-input" placeholder="e.g. Acme Corp" value={form.client} onChange={update('client')} />
          {errors.client && <div className="form-error">{errors.client}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Amount (USD) *</label>
          <input className="form-input" type="number" placeholder="e.g. 5000" value={form.amount} onChange={update('amount')} />
          {errors.amount && <div className="form-error">{errors.amount}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Status</label>
          <select className="form-input form-select" value={form.status} onChange={update('status')}>
            {['Draft', 'Pending', 'Paid', 'Overdue'].map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Invoice Date</label>
          <input className="form-input" type="date" value={form.date} onChange={update('date')} />
        </div>
      </Modal>
    </div>
  );
}
