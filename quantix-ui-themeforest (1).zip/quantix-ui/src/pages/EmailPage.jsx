import { useState } from 'react';
import Modal from '../components/ui/Modal';
import { initialEmails, generateId } from '../data/mockData';

const FOLDERS = [
  { id: 'inbox', icon: '📥', label: 'Inbox' },
  { id: 'starred', icon: '⭐', label: 'Starred' },
  { id: 'sent', icon: '📤', label: 'Sent' },
  { id: 'drafts', icon: '📝', label: 'Drafts' },
  { id: 'trash', icon: '🗑️', label: 'Trash' },
];

function validateCompose(form) {
  const errs = {};
  if (!form.to || !/\S+@\S+\.\S+/.test(form.to)) errs.to = 'Valid email required';
  if (!form.subject.trim()) errs.subject = 'Subject required';
  return errs;
}

export default function EmailPage({ toast }) {
  const [emails, setEmails] = useState(initialEmails);
  const [folder, setFolder] = useState('inbox');
  const [selected, setSelected] = useState(null);
  const [showCompose, setShowCompose] = useState(false);
  const [compose, setCompose] = useState({ to: '', subject: '', body: '' });
  const [composeErrors, setComposeErrors] = useState({});

  const updateCompose = (field) => (e) => {
    setCompose((prev) => ({ ...prev, [field]: e.target.value }));
    setComposeErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const getEmails = () => {
    if (folder === 'starred') return [...emails.inbox, ...emails.sent].filter((e) => e.starred);
    return emails[folder] ?? [];
  };

  const unreadCount = (folderId) => {
    if (folderId === 'inbox') return emails.inbox.filter((e) => !e.read).length;
    if (folderId === 'drafts') return emails.drafts.length;
    return 0;
  };

  const markRead = (id) => {
    setEmails((prev) => ({ ...prev, inbox: prev.inbox.map((e) => e.id === id ? { ...e, read: true } : e) }));
  };

  const toggleStar = (id) => {
    const toggle = (arr) => arr.map((e) => e.id === id ? { ...e, starred: !e.starred } : e);
    setEmails((prev) => ({ ...prev, inbox: toggle(prev.inbox), sent: toggle(prev.sent) }));
  };

  const deleteEmail = (email) => {
    const remove = (arr) => arr.filter((e) => e.id !== email.id);
    if (folder === 'trash') {
      setEmails((prev) => ({ ...prev, trash: remove(prev.trash) }));
    } else {
      setEmails((prev) => ({ ...prev, [folder]: remove(prev[folder]), trash: [...prev.trash, email] }));
    }
    setSelected(null);
    toast('Moved to trash', 'info');
  };

  const restoreEmail = (email) => {
    setEmails((prev) => ({ ...prev, trash: prev.trash.filter((e) => e.id !== email.id), inbox: [...prev.inbox, email] }));
    toast('Restored to inbox');
  };

  const sendEmail = () => {
    const errs = validateCompose(compose);
    if (Object.keys(errs).length > 0) { setComposeErrors(errs); return; }
    const sent = { id: generateId(), from: 'Me', to: compose.to, subject: compose.subject, preview: compose.body.slice(0, 80), date: 'Just now', read: true, starred: false };
    setEmails((prev) => ({ ...prev, sent: [sent, ...prev.sent] }));
    setShowCompose(false);
    setCompose({ to: '', subject: '', body: '' });
    toast('Email sent!');
  };

  const saveDraft = () => {
    const draft = { id: generateId(), from: 'Me', subject: compose.subject || '(no subject)', preview: compose.body.slice(0, 60), date: 'Now', read: true, starred: false };
    setEmails((prev) => ({ ...prev, drafts: [draft, ...prev.drafts] }));
    setShowCompose(false);
    setCompose({ to: '', subject: '', body: '' });
    toast('Draft saved', 'info');
  };

  const curEmails = getEmails();

  return (
    <div>
      <div className="page-header">
        <div className="page-title">Email</div>
        <button className="btn btn-primary" onClick={() => setShowCompose(true)}>✏️ Compose</button>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="email-layout">
          {/* Folder sidebar */}
          <div className="email-sidebar">
            {FOLDERS.map((f) => {
              const count = unreadCount(f.id);
              return (
                <div key={f.id} className={`email-folder${folder === f.id ? ' active' : ''}`} onClick={() => { setFolder(f.id); setSelected(null); }}>
                  <span>{f.icon}</span>
                  <span style={{ flex: 1 }}>{f.label}</span>
                  {count > 0 && <span className="nav-badge">{count}</span>}
                </div>
              );
            })}
          </div>

          {/* Email list */}
          <div className="email-list">
            {curEmails.length === 0 ? (
              <div style={{ padding: 24, textAlign: 'center', color: 'var(--text3)', fontSize: 13 }}>No emails here</div>
            ) : curEmails.map((e) => (
              <div
                key={e.id}
                className={`email-item${selected?.id === e.id ? ' active-email' : ''}${!e.read ? ' unread' : ''}`}
                onClick={() => { setSelected(e); if (!e.read) markRead(e.id); }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="email-from">{e.from}</span>
                  <span className="email-date">{e.date}</span>
                </div>
                <div className="email-subject">{e.subject}</div>
                <div className="email-preview-text">{e.preview}</div>
              </div>
            ))}
          </div>

          {/* Email view */}
          <div className="email-view">
            {selected ? (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div style={{ fontWeight: 800, fontSize: 18 }}>{selected.subject}</div>
                  <div className="flex gap-2">
                    <button className="btn btn-ghost btn-sm" onClick={() => toggleStar(selected.id)}>
                      {selected.starred ? '⭐' : '☆'} Star
                    </button>
                    {folder === 'trash' ? (
                      <button className="btn btn-secondary btn-sm" onClick={() => restoreEmail(selected)}>↩ Restore</button>
                    ) : (
                      <button className="btn btn-danger btn-sm" onClick={() => deleteEmail(selected)}>🗑 Delete</button>
                    )}
                  </div>
                </div>
                <div style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 20 }}>
                  <strong>From:</strong> {selected.from} &nbsp; <strong>Date:</strong> {selected.date}
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.7, color: 'var(--text2)' }}>{selected.preview}</div>
                <div style={{ marginTop: 20, padding: 12, background: 'var(--bg3)', borderRadius: 8, fontSize: 13, color: 'var(--text3)' }}>
                  [Full email body would display here in production. This is the preview in demo mode.]
                </div>
              </>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text3)' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>✉️</div>
                <div>Select an email to read</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Compose Modal */}
      <Modal
        open={showCompose}
        onClose={() => setShowCompose(false)}
        title="✏️ New Message"
        size="lg"
        footer={
          <>
            <button className="btn btn-secondary" onClick={saveDraft}>Save Draft</button>
            <button className="btn btn-secondary" onClick={() => setShowCompose(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={sendEmail}>Send ✉️</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">To</label>
          <input className="form-input" type="email" placeholder="recipient@example.com" value={compose.to} onChange={updateCompose('to')} />
          {composeErrors.to && <div className="form-error">{composeErrors.to}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Subject</label>
          <input className="form-input" placeholder="Email subject" value={compose.subject} onChange={updateCompose('subject')} />
          {composeErrors.subject && <div className="form-error">{composeErrors.subject}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Message</label>
          <textarea className="form-input form-textarea" rows={8} placeholder="Write your message…" value={compose.body} onChange={updateCompose('body')} />
        </div>
      </Modal>
    </div>
  );
}
