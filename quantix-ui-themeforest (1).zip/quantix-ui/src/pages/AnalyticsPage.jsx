import { useState, useRef, useEffect } from 'react';
import {
  AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import KPICard from '../components/ui/KPICard';
import ChartCard from '../components/charts/ChartCard';
import { revenueData, trafficData, formatNumber } from '../data/mockData';

const kpis = [
  { label: 'Total Revenue', value: '$1.24M', change: '+22%', trend: 'up', accent: 'purple' },
  { label: 'Avg Session', value: '4m 32s', change: '+8%', trend: 'up', accent: 'cyan' },
  { label: 'Bounce Rate', value: '38.2%', change: '-4%', trend: 'up', accent: 'orange' },
  { label: 'Conversion', value: '3.7%', change: '+0.9%', trend: 'up', accent: 'green' },
];

const dataByPeriod = {
  '7d': revenueData.slice(-3),
  '30d': revenueData.slice(-5),
  '90d': revenueData,
};

export default function AnalyticsPage({ toast }) {
  const [period, setPeriod] = useState('30d');
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const exportCSV = (type) => {
    let rows, filename;
    if (type === 'revenue') {
      rows = [['Month', 'Revenue', 'Expenses', 'Profit'], ...revenueData.map((r) => [r.month, r.revenue, r.expenses, r.revenue - r.expenses])];
      filename = 'analytics-revenue.csv';
    } else {
      rows = [['Day', 'Organic', 'Paid', 'Direct'], ...trafficData.map((r) => [r.day, r.organic, r.paid, r.direct])];
      filename = 'analytics-traffic.csv';
    }
    const csv = rows.map((r) => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = filename;
    a.click();
    setShowExportMenu(false);
    toast('Export downloaded!');
  };

  const periodToggle = (
    <div className="toggle-group">
      {['7d', '30d', '90d'].map((p) => (
        <div key={p} className={`toggle-btn${period === p ? ' active' : ''}`} onClick={() => setPeriod(p)}>{p}</div>
      ))}
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Analytics</div>
          <div className="page-subtitle">Performance insights and traffic overview</div>
        </div>
        <div className="relative" ref={exportRef}>
          <button className="btn btn-secondary" onClick={() => setShowExportMenu((v) => !v)}>
            ⬇️ Export ▾
          </button>
          {showExportMenu && (
            <div className="dropdown" style={{ right: 0, minWidth: 200 }}>
              <div className="dropdown-item" onClick={() => exportCSV('revenue')}>📊 Revenue Data (CSV)</div>
              <div className="dropdown-item" onClick={() => exportCSV('traffic')}>📈 Traffic Data (CSV)</div>
            </div>
          )}
        </div>
      </div>

      <div className="grid-4 section-gap">
        {kpis.map((k) => <KPICard key={k.label} {...k} />)}
      </div>

      <ChartCard title="Revenue Overview" action={periodToggle} height={260} style={{ marginBottom: 16 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={dataByPeriod[period]}>
            <defs>
              <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="var(--accent)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent2)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="var(--accent2)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="month" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}K`} />
            <Tooltip contentStyle={{ background: 'var(--bg2)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} formatter={(v) => `$${v.toLocaleString()}`} />
            <Area type="monotone" dataKey="revenue" stroke="var(--accent)" fill="url(#gRev)" strokeWidth={2} name="Revenue" />
            <Area type="monotone" dataKey="expenses" stroke="var(--accent2)" fill="url(#gExp)" strokeWidth={2} name="Expenses" />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ marginTop: 16 }}>
        <ChartCard title="Traffic Sources (Weekly)" height={220}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trafficData} barSize={10} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="day" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={formatNumber} />
              <Tooltip contentStyle={{ background: 'var(--bg2)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="organic" fill="var(--accent)" radius={[4, 4, 0, 0]} name="Organic" />
              <Bar dataKey="paid" fill="var(--accent2)" radius={[4, 4, 0, 0]} name="Paid" />
              <Bar dataKey="direct" fill="var(--accent3)" radius={[4, 4, 0, 0]} name="Direct" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}
