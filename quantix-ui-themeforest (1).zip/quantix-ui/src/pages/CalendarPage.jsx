import { useState } from 'react';
import Modal from '../components/ui/Modal';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

export default function CalendarPage({ toast }) {
  const today = new Date();
  const [cur, setCur] = useState({ year: today.getFullYear(), month: today.getMonth() });
  const [events, setEvents] = useState([
    { id: 1, date: `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-15`, title: 'Product sync', color: 'var(--accent)' },
    { id: 2, date: `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-18`, title: 'Investor call', color: 'var(--green)' },
    { id: 3, date: `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-22`, title: 'Sprint review', color: 'var(--orange)' },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [selDate, setSelDate] = useState('');
  const [newTitle, setNewTitle] = useState('');

  const daysInMonth = new Date(cur.year, cur.month + 1, 0).getDate();
  const firstDay = new Date(cur.year, cur.month, 1).getDay();
  const prevDays = new Date(cur.year, cur.month, 0).getDate();

  const addEvent = () => {
    if (!newTitle.trim() || !selDate) return;
    setEvents((prev) => [...prev, { id: Date.now(), date: selDate, title: newTitle.trim(), color: 'var(--accent)' }]);
    setShowModal(false);
    setNewTitle('');
    toast('Event added!');
  };

  const deleteEvent = (id) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
    toast('Event deleted', 'info');
  };

  const todayStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  const fmtDate = (d) => `${cur.year}-${String(cur.month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;

  const cells = [];
  for (let i = firstDay - 1; i >= 0; i--) cells.push({ day: prevDays - i, type: 'prev' });
  for (let i = 1; i <= daysInMonth; i++) cells.push({ day: i, type: 'cur' });
  const rem = 42 - cells.length;
  for (let i = 1; i <= rem; i++) cells.push({ day: i, type: 'next' });

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Calendar</div><div className="page-subtitle">Schedule and event management</div></div>
        <button className="btn btn-primary" onClick={() => { setSelDate(todayStr); setShowModal(true); }}>+ Add Event</button>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div style={{ fontSize: 18, fontWeight: 800 }}>{MONTHS[cur.month]} {cur.year}</div>
          <div className="flex gap-2">
            <button className="btn btn-secondary btn-sm" onClick={() => setCur((p) => p.month === 0 ? { year: p.year - 1, month: 11 } : { ...p, month: p.month - 1 })}>←</button>
            <button className="btn btn-secondary btn-sm" onClick={() => setCur({ year: today.getFullYear(), month: today.getMonth() })}>Today</button>
            <button className="btn btn-secondary btn-sm" onClick={() => setCur((p) => p.month === 11 ? { year: p.year + 1, month: 0 } : { ...p, month: p.month + 1 })}>→</button>
          </div>
        </div>

        <div className="cal-grid mb-2">
          {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d) => <div key={d} className="cal-day-header">{d}</div>)}
        </div>

        <div className="cal-grid">
          {cells.map((c, i) => {
            const ds = c.type === 'cur' ? fmtDate(c.day) : '';
            const dayEvents = events.filter((e) => e.date === ds);
            const isToday = ds === todayStr;
            return (
              <div
                key={i}
                className={`cal-cell${isToday ? ' today' : ''}${c.type !== 'cur' ? ' other-month' : ''}`}
                onClick={() => { if (c.type === 'cur') { setSelDate(ds); setShowModal(true); } }}
              >
                <div className="cal-date" style={{ color: isToday ? 'var(--accent)' : 'inherit' }}>{c.day}</div>
                {dayEvents.map((ev) => (
                  <div
                    key={ev.id}
                    className="cal-event"
                    style={{ background: ev.color }}
                    onClick={(e) => { e.stopPropagation(); deleteEvent(ev.id); }}
                    title={`Click to delete: ${ev.title}`}
                  >
                    {ev.title}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Add Event"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addEvent} disabled={!newTitle.trim()}>Add Event</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Date</label>
          <input className="form-input" type="date" value={selDate} onChange={(e) => setSelDate(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Event Title</label>
          <input
            className="form-input"
            placeholder="e.g. Team standup"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addEvent()}
            autoFocus
          />
        </div>
      </Modal>
    </div>
  );
}
