import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

export default function LoginPage() {
  const { login, loading, error, setError } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });

  const update = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    if (error) setError('');
  };

  const handleSubmit = async () => {
    if (!form.email || !form.password) {
      setError('Please fill in all fields.');
      return;
    }
    const result = await login(form.email, form.password);
    if (result.success) navigate('/dashboard', { replace: true });
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="brand-icon">✦</div>
          <div>
            <div className="brand-name">Quantix UI</div>
            <div style={{ fontSize: 10, color: 'var(--text3)' }}>Admin Analytics Hub</div>
          </div>
        </div>

        <div className="auth-title">Welcome back</div>
        <div className="auth-subtitle">Sign in to your dashboard</div>

        {error && <div className="auth-alert auth-alert-error">{error}</div>}

        <div className="form-group">
          <label className="form-label" htmlFor="email">Email address</label>
          <input
            id="email"
            className="form-input"
            type="email"
            placeholder="admin@quantix.io"
            value={form.email}
            onChange={update('email')}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            autoComplete="email"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="password">Password</label>
          <input
            id="password"
            className="form-input"
            type="password"
            placeholder="••••••••"
            value={form.password}
            onChange={update('password')}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            autoComplete="current-password"
          />
        </div>

        <div style={{ textAlign: 'right', marginBottom: 16 }}>
          <Link to="/forgot-password" className="auth-link text-sm">Forgot password?</Link>
        </div>

        <button
          className="btn btn-primary w-full"
          onClick={handleSubmit}
          disabled={loading}
          style={{ justifyContent: 'center', height: 40 }}
        >
          {loading ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span className="spinner" />
              Signing in…
            </span>
          ) : 'Sign in'}
        </button>

        <div className="auth-divider">or</div>

        <div className="text-sm" style={{ textAlign: 'center', color: 'var(--text2)' }}>
          Don't have an account?{' '}
          <Link to="/register" className="auth-link">Create one</Link>
        </div>

        <div className="auth-alert auth-alert-info" style={{ marginTop: 16, marginBottom: 0 }}>
          <strong>Demo credentials:</strong><br />
          admin@quantix.io / admin123
        </div>
      </div>
    </div>
  );
}
