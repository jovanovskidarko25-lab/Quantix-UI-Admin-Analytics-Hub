import { useState } from 'react';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import { initialKanban, generateId } from '../data/mockData';

const COLUMNS = [
  { id: 'todo', label: 'To Do', color: 'var(--text3)' },
  { id: 'inprogress', label: 'In Progress', color: 'var(--accent)' },
  { id: 'review', label: 'Review', color: 'var(--orange)' },
  { id: 'done', label: 'Done', color: 'var(--green)' },
];

const TAGS = ['Dev', 'Design', 'Research', 'Testing', 'DevOps', 'Docs', 'QA', 'Marketing'];

export default function KanbanPage({ toast }) {
  const [board, setBoard] = useState(initialKanban);
  const [dragging, setDragging] = useState(null);
  const [dragOver, setDragOver] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ title: '', tag: 'Dev', priority: 'Medium', column: 'todo' });
  const [formError, setFormError] = useState('');

  const update = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const addTask = () => {
    if (!form.title.trim()) { setFormError('Task title is required'); return; }
    setFormError('');
    const card = { id: generateId(), title: form.title.trim(), tag: form.tag, priority: form.priority };
    setBoard((prev) => ({ ...prev, [form.column]: [...prev[form.column], card] }));
    setShowModal(false);
    setForm({ title: '', tag: 'Dev', priority: 'Medium', column: 'todo' });
    toast('Task added!');
  };

  const deleteCard = (cardId, colId) => {
    setBoard((prev) => ({ ...prev, [colId]: prev[colId].filter((c) => c.id !== cardId) }));
    toast('Task deleted', 'info');
  };

  const openAddInCol = (colId) => {
    setForm((prev) => ({ ...prev, column: colId }));
    setShowModal(true);
  };

  const onDragStart = (e, card, fromCol) => {
    setDragging({ card, fromCol });
    e.dataTransfer.effectAllowed = 'move';
  };

  const onDragOver = (e, colId) => {
    e.preventDefault();
    setDragOver(colId);
  };

  const onDrop = (e, toCol) => {
    e.preventDefault();
    if (!dragging || dragging.fromCol === toCol) { setDragging(null); setDragOver(null); return; }
    setBoard((prev) => ({
      ...prev,
      [dragging.fromCol]: prev[dragging.fromCol].filter((c) => c.id !== dragging.card.id),
      [toCol]: [...prev[toCol], dragging.card],
    }));
    setDragging(null);
    setDragOver(null);
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Kanban Board</div>
          <div className="page-subtitle">Drag & drop to manage tasks</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Task</button>
      </div>

      <div className="kanban-board">
        {COLUMNS.map((col) => (
          <div
            key={col.id}
            className="kanban-col"
            onDragOver={(e) => onDragOver(e, col.id)}
            onDrop={(e) => onDrop(e, col.id)}
            style={{ borderTop: `3px solid ${col.color}`, background: dragOver === col.id ? 'var(--glow)' : 'var(--bg2)' }}
          >
            <div className="kanban-col-header">
              <span>{col.label}</span>
              <span style={{ background: 'var(--bg4)', borderRadius: 99, padding: '1px 8px', fontSize: 12 }}>
                {board[col.id].length}
              </span>
            </div>

            <div className="kanban-cards">
              {board[col.id].map((card) => (
                <div
                  key={card.id}
                  className={`kanban-card${dragging?.card.id === card.id ? ' dragging' : ''}`}
                  draggable
                  onDragStart={(e) => onDragStart(e, card, col.id)}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginBottom: 8 }}>
                    <div className="kanban-card-title" style={{ margin: 0, flex: 1 }}>{card.title}</div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteCard(card.id, col.id); }}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 12, padding: '0 2px', flexShrink: 0 }}
                      title="Delete"
                    >✕</button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span style={{ fontSize: 11, background: 'var(--bg4)', borderRadius: 4, padding: '2px 6px', color: 'var(--text2)' }}>
                      {card.tag}
                    </span>
                    <Badge variant={card.priority.toLowerCase()} style={{ fontSize: 10 }}>{card.priority}</Badge>
                  </div>
                </div>
              ))}

              <button
                className="btn btn-ghost btn-xs w-full"
                style={{ color: 'var(--text3)', fontSize: 11, marginTop: 4 }}
                onClick={() => openAddInCol(col.id)}
              >
                + Add card
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal
        open={showModal}
        onClose={() => { setShowModal(false); setFormError(''); }}
        title="📌 Add New Task"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addTask}>Add Task</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Task Title *</label>
          <input
            className="form-input"
            placeholder="e.g. Implement auth flow"
            value={form.title}
            onChange={update('title')}
            onKeyDown={(e) => e.key === 'Enter' && addTask()}
            autoFocus
          />
          {formError && <div className="form-error">{formError}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Column</label>
          <select className="form-input form-select" value={form.column} onChange={update('column')}>
            {COLUMNS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Tag</label>
            <select className="form-input form-select" value={form.tag} onChange={update('tag')}>
              {TAGS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Priority</label>
            <select className="form-input form-select" value={form.priority} onChange={update('priority')}>
              {['Low', 'Medium', 'High', 'Critical'].map((v) => <option key={v}>{v}</option>)}
            </select>
          </div>
        </div>
      </Modal>
    </div>
  );
}
