import { useState } from 'react';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import { initialProjects, generateId } from '../data/mockData';

export default function ProjectsPage({ toast }) {
  const [projects, setProjects] = useState(initialProjects);
  const [showCreate, setShowCreate] = useState(false);
  const [detail, setDetail] = useState(null);
  const [form, setForm] = useState({ name: '', priority: 'Medium', due: '', team: '' });
  const [formError, setFormError] = useState('');

  const update = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const addProject = () => {
    if (!form.name.trim()) { setFormError('Project name is required'); return; }
    setFormError('');
    const teamArr = form.team.trim()
      ? form.team.split(',').map((t) => t.trim().slice(0, 2).toUpperCase()).filter(Boolean)
      : ['NA'];
    const dueLabel = form.due
      ? new Date(form.due).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      : 'TBD';

    setProjects((prev) => [...prev, {
      id: generateId(),
      name: form.name.trim(),
      status: 'Planning',
      progress: 0,
      team: teamArr,
      due: dueLabel,
      priority: form.priority,
    }]);

    setShowCreate(false);
    setForm({ name: '', priority: 'Medium', due: '', team: '' });
    toast('Project created!');
  };

  const closeCreate = () => {
    setShowCreate(false);
    setFormError('');
    setForm({ name: '', priority: 'Medium', due: '', team: '' });
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Projects</div>
          <div className="page-subtitle">{projects.length} active projects</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)}>+ New Project</button>
      </div>

      <div className="grid-2">
        {projects.map((p) => (
          <div key={p.id} className="card" style={{ cursor: 'pointer' }} onClick={() => setDetail(p)}>
            <div className="flex items-center justify-between mb-2">
              <div style={{ fontWeight: 700, fontSize: 15 }}>{p.name}</div>
              <Badge variant={p.priority.toLowerCase()}>{p.priority}</Badge>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <Badge variant={p.status.toLowerCase().replace(' ', '-')}>{p.status}</Badge>
              <span className="text-sm text-muted">Due: {p.due}</span>
            </div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted">Progress</span>
              <span style={{ fontSize: 13, fontWeight: 700 }}>{p.progress}%</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${p.progress}%` }} />
            </div>
            <div className="flex gap-1 mt-3">
              {p.team.map((m) => (
                <div key={m} style={{ width: 26, height: 26, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: 'white', border: '2px solid var(--bg2)' }}>
                  {m}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      <Modal
        open={showCreate}
        onClose={closeCreate}
        title="🗂️ New Project"
        footer={
          <>
            <button className="btn btn-secondary" onClick={closeCreate}>Cancel</button>
            <button className="btn btn-primary" onClick={addProject}>Create Project</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Project Name *</label>
          <input className="form-input" placeholder="e.g. Platform v3 Launch" value={form.name} onChange={update('name')} onKeyDown={(e) => e.key === 'Enter' && addProject()} />
          {formError && <div className="form-error">{formError}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Priority</label>
          <select className="form-input form-select" value={form.priority} onChange={update('priority')}>
            {['Low', 'Medium', 'High', 'Critical'].map((v) => <option key={v}>{v}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Due Date</label>
          <input className="form-input" type="date" value={form.due} onChange={update('due')} />
        </div>
        <div className="form-group">
          <label className="form-label">Team Members</label>
          <input className="form-input" placeholder="AK, SR, MJ" value={form.team} onChange={update('team')} />
          <div className="form-hint">Comma-separated initials, e.g. AK, SR</div>
        </div>
      </Modal>

      {/* Detail Modal */}
      <Modal
        open={Boolean(detail)}
        onClose={() => setDetail(null)}
        title={detail?.name ?? ''}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setDetail(null)}>Close</button>
            <button className="btn btn-primary" onClick={() => { setDetail(null); toast('Edit mode coming soon', 'info'); }}>
              Edit Project
            </button>
          </>
        }
      >
        {detail && (
          <>
            <div className="grid-2 mb-3">
              <div><div className="text-xs text-dim mb-1">Status</div><Badge variant={detail.status.toLowerCase().replace(' ', '-')}>{detail.status}</Badge></div>
              <div><div className="text-xs text-dim mb-1">Priority</div><Badge variant={detail.priority.toLowerCase()}>{detail.priority}</Badge></div>
              <div><div className="text-xs text-dim mb-1">Due Date</div><div style={{ fontWeight: 600, fontSize: 13 }}>{detail.due}</div></div>
              <div><div className="text-xs text-dim mb-1">Progress</div><div style={{ fontWeight: 700, fontSize: 22, color: 'var(--accent)' }}>{detail.progress}%</div></div>
            </div>
            <div className="progress-bar mb-3">
              <div className="progress-fill" style={{ width: `${detail.progress}%` }} />
            </div>
            <div>
              <div className="text-xs text-dim mb-2">Team Members</div>
              <div className="flex gap-2">
                {detail.team.map((m) => (
                  <div key={m} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--bg3)', borderRadius: 99, padding: '4px 10px', fontSize: 12, fontWeight: 600 }}>
                    <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: 'white' }}>{m}</div>
                    {m}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}
