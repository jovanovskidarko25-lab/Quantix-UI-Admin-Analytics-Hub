import { useState, useRef, useEffect } from 'react';
import { initialConversations, generateId } from '../data/mockData';

const AI_RESPONSES = [
  "Based on the current dashboard data, I've analyzed your query. The key metrics show **positive momentum** across all major KPIs.\n\n**Key insights:**\n1. Revenue is tracking 18% above target\n2. User engagement improved significantly\n3. Churn rate is at an all-time low\n\nWould you like a deeper breakdown of any specific area?",
  "Great question! Looking at the trends in your analytics:\n\n- **Traffic**: Organic up 24% MoM\n- **Conversions**: 3.7% (industry avg: 2.1%)\n- **Revenue per user**: $47 (+$12 vs last quarter)\n\nI recommend focusing on the enterprise segment — it shows the highest growth potential.",
  "I've reviewed your request. Here's what the data suggests:\n\n1. **Immediate action**: Review the overdue invoices — $28K is outstanding\n2. **Quick win**: Three leads marked 'Hot' haven't been contacted in 5+ days\n3. **Strategic**: Your AI usage is growing 34% — consider upgrading compute allocation\n\nShall I generate a full action plan?",
];

function renderMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br/>');
}

export default function ChatPage() {
  const [conversations, setConversations] = useState(initialConversations);
  const [activeId, setActiveId] = useState(initialConversations[0].id);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  const active = conversations.find((c) => c.id === activeId);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [active?.messages, typing]);

  const send = () => {
    const text = input.trim();
    if (!text || typing) return;
    setInput('');

    setConversations((prev) => prev.map((c) =>
      c.id === activeId ? { ...c, messages: [...c.messages, { role: 'user', content: text }] } : c
    ));

    setTyping(true);
    setTimeout(() => {
      const reply = AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];
      setTyping(false);
      setConversations((prev) => prev.map((c) =>
        c.id === activeId ? { ...c, messages: [...c.messages, { role: 'ai', content: reply }] } : c
      ));
    }, 1000 + Math.random() * 800);
  };

  const newChat = () => {
    const id = generateId();
    setConversations((prev) => [...prev, { id, title: 'New conversation', messages: [] }]);
    setActiveId(id);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  return (
    <div>
      <div className="page-header" style={{ marginBottom: 12 }}>
        <div className="page-title">AI Chat</div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="chat-layout">
          {/* Sidebar */}
          <div className="chat-sidebar">
            <button className="btn btn-primary w-full mb-3" onClick={newChat} style={{ justifyContent: 'center' }}>
              + New Chat
            </button>
            {conversations.map((c) => (
              <div
                key={c.id}
                className={`conv-item${activeId === c.id ? ' active' : ''}`}
                onClick={() => setActiveId(c.id)}
              >
                💬 {c.title}
              </div>
            ))}
          </div>

          {/* Main */}
          <div className="chat-main">
            <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', fontWeight: 700, fontSize: 14 }}>
              {active?.title}
            </div>

            <div className="chat-messages">
              {active?.messages.length === 0 && (
                <div style={{ textAlign: 'center', color: 'var(--text3)', marginTop: 60 }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>🤖</div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>How can I help you today?</div>
                  <div style={{ fontSize: 12, marginTop: 4 }}>Ask me anything about your data</div>
                </div>
              )}

              {active?.messages.map((m, i) => (
                <div key={i} className={`chat-msg ${m.role}`}>
                  <div
                    className="user-avatar"
                    style={{
                      background: m.role === 'user' ? 'var(--accent2)' : 'var(--bg4)',
                      color: m.role === 'user' ? 'white' : 'var(--accent)',
                      fontSize: 11,
                      width: 32,
                      height: 32,
                      flexShrink: 0,
                      alignSelf: 'flex-start',
                    }}
                  >
                    {m.role === 'user' ? 'AM' : 'AI'}
                  </div>
                  <div
                    className="chat-bubble"
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
                  />
                </div>
              ))}

              {typing && (
                <div className="chat-msg ai">
                  <div className="user-avatar" style={{ background: 'var(--bg4)', color: 'var(--accent)', fontSize: 11, width: 32, height: 32, flexShrink: 0 }}>AI</div>
                  <div className="chat-bubble">
                    <div className="typing-indicator">
                      <div className="typing-dot" />
                      <div className="typing-dot" />
                      <div className="typing-dot" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <div className="chat-input-area">
              <div className="chat-input-row">
                <textarea
                  ref={inputRef}
                  className="chat-textarea"
                  placeholder="Type a message… (Enter to send, Shift+Enter for newline)"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
                  rows={1}
                />
                <button className="btn btn-primary" onClick={send} disabled={!input.trim() || typing}>
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
