import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Modal from '../components/ui/Modal';

const PLANS = [
  { name: 'Starter', price: '$29', features: ['5 users', '10 projects', 'Basic analytics', 'Email support'] },
  { name: 'Pro', price: '$79', features: ['25 users', 'Unlimited projects', 'Advanced AI', 'Priority support'], recommended: true },
  { name: 'Enterprise', price: '$199', features: ['Unlimited users', 'Custom integrations', 'Dedicated manager', 'SLA guarantee'] },
];

function validateProfile(form) {
  const errs = {};
  if (!form.name.trim()) errs.name = 'Name required';
  if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Valid email required';
  return errs;
}

function validateCard(card) {
  const errs = {};
  if (!card.number || card.number.replace(/\s/g, '').length < 16) errs.number = 'Enter 16-digit card number';
  if (!card.name.trim()) errs.name = 'Required';
  if (!card.expiry || !/^\d{2}\/\d{2}$/.test(card.expiry)) errs.expiry = 'Format: MM/YY';
  if (!card.cvc || card.cvc.length < 3) errs.cvc = '3–4 digits required';
  return errs;
}

export default function SettingsPage({ toast }) {
  const [searchParams] = useSearchParams();
  const [tab, setTab] = useState(searchParams.get('tab') === 'billing' ? 'billing' : 'profile');

  // Profile state
  const [profile, setProfile] = useState({ name: 'Alex Morgan', email: 'admin@quantix.io', company: 'Quantix Labs', role: 'Super Admin' });
  const [profileErrors, setProfileErrors] = useState({});
  const [avatarPreview, setAvatarPreview] = useState(null);

  // Billing state
  const [plan, setPlan] = useState('Pro');
  const [subStatus, setSubStatus] = useState('Active');
  const [cards, setCards] = useState([{ id: 1, last4: '4242', brand: 'Visa', expiry: '12/26', name: 'Alex Morgan', isDefault: true }]);

  // Modals
  const [showPlanModal, setShowPlanModal] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);
  const [newCard, setNewCard] = useState({ number: '', name: '', expiry: '', cvc: '' });
  const [cardErrors, setCardErrors] = useState({});

  const updateProfile = (field) => (e) => {
    setProfile((prev) => ({ ...prev, [field]: e.target.value }));
    setProfileErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const saveProfile = () => {
    const errs = validateProfile(profile);
    if (Object.keys(errs).length > 0) { setProfileErrors(errs); return; }
    localStorage.setItem('qx_profile', JSON.stringify(profile));
    toast('Profile saved!');
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast('Please select an image file', 'error'); return; }
    if (file.size > 2 * 1024 * 1024) { toast('Image must be under 2MB', 'error'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => { setAvatarPreview(ev.target.result); toast('Photo updated!'); };
    reader.readAsDataURL(file);
  };

  const addCard = () => {
    const errs = validateCard(newCard);
    if (Object.keys(errs).length > 0) { setCardErrors(errs); return; }
    const last4 = newCard.number.replace(/\s/g, '').slice(-4);
    setCards((prev) => [...prev, { id: Date.now(), last4, brand: 'Card', expiry: newCard.expiry, name: newCard.name, isDefault: false }]);
    setShowAddCard(false);
    setNewCard({ number: '', name: '', expiry: '', cvc: '' });
    setCardErrors({});
    toast('Payment method added!');
  };

  const setDefaultCard = (id) => {
    setCards((prev) => prev.map((c) => ({ ...c, isDefault: c.id === id })));
    toast('Default card updated');
  };

  const removeCard = (id) => {
    const card = cards.find((c) => c.id === id);
    if (card?.isDefault) { toast("Can't delete your default card", 'error'); return; }
    setCards((prev) => prev.filter((c) => c.id !== id));
    toast('Card removed', 'info');
  };

  const formatCardNum = (v) => v.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim().slice(0, 19);
  const updateCard = (field) => (e) => {
    setNewCard((prev) => ({ ...prev, [field]: e.target.value }));
    setCardErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Settings</div><div className="page-subtitle">Manage your account preferences</div></div>
      </div>

      <div className="settings-nav">
        {['profile', 'billing'].map((t) => (
          <div key={t} className={`settings-tab${tab === t ? ' active' : ''}`} onClick={() => setTab(t)}>
            {t === 'profile' ? '👤 Profile' : '💳 Billing'}
          </div>
        ))}
      </div>

      {/* ─── Profile Tab ─── */}
      {tab === 'profile' && (
        <div className="grid-2" style={{ alignItems: 'start' }}>
          <div className="card">
            <div className="card-title mb-3">Profile Photo</div>
            <div className="flex items-center gap-4 mb-4">
              <label style={{ cursor: 'pointer' }}>
                <div className="avatar-upload">
                  {avatarPreview
                    ? <img src={avatarPreview} alt="Avatar" />
                    : <div className="avatar-fallback">AM</div>}
                  <div className="avatar-upload-overlay">📷</div>
                </div>
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handleAvatarChange} />
              </label>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{profile.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text3)' }}>{profile.role}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>Click to change · Max 2MB</div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-title mb-3">Account Information</div>
            {[['name', 'Full Name', 'text'], ['email', 'Email', 'email'], ['company', 'Company', 'text'], ['role', 'Role', 'text']].map(([f, l, t]) => (
              <div className="form-group" key={f}>
                <label className="form-label">{l}</label>
                <input className="form-input" type={t} value={profile[f]} onChange={updateProfile(f)} />
                {profileErrors[f] && <div className="form-error">{profileErrors[f]}</div>}
              </div>
            ))}
            <button className="btn btn-primary" onClick={saveProfile}>Save Changes</button>
          </div>
        </div>
      )}

      {/* ─── Billing Tab ─── */}
      {tab === 'billing' && (
        <>
          {/* Plans */}
          <div className="card section-gap">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="card-title">Current Plan</div>
                <div className="card-sub">
                  You're on the <strong>{plan}</strong> plan —&nbsp;
                  <span style={{ color: subStatus === 'Active' ? 'var(--green)' : 'var(--red)' }}>{subStatus}</span>
                </div>
              </div>
              {subStatus === 'Active'
                ? <button className="btn btn-danger btn-sm" onClick={() => setShowCancelModal(true)}>Cancel Plan</button>
                : <button className="btn btn-success btn-sm" onClick={() => { setSubStatus('Active'); toast('Subscription reactivated!'); }}>Reactivate</button>
              }
            </div>
            <div className="grid-3">
              {PLANS.map((p) => (
                <div key={p.name} className={`pricing-card${p.recommended ? ' recommended' : ''}`}>
                  {p.recommended && <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--accent)', marginBottom: 4 }}>✦ RECOMMENDED</div>}
                  <div style={{ fontWeight: 800, fontSize: 16 }}>{p.name}</div>
                  <div className="pricing-price">{p.price}<span className="pricing-period">/mo</span></div>
                  {p.features.map((f) => (
                    <div key={f} className="pricing-feature"><span style={{ color: 'var(--green)' }}>✓</span> {f}</div>
                  ))}
                  <button
                    className={`btn ${plan === p.name ? 'btn-secondary' : 'btn-primary'} w-full mt-3`}
                    style={{ justifyContent: 'center' }}
                    onClick={() => plan !== p.name && setShowPlanModal(p.name)}
                  >
                    {plan === p.name ? 'Current Plan' : 'Upgrade'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Methods */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="card-title">Payment Methods</div>
              <button className="btn btn-primary btn-sm" onClick={() => setShowAddCard(true)}>+ Add Card</button>
            </div>
            {cards.map((c) => (
              <div key={c.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 12, background: 'var(--bg3)', borderRadius: 8, marginBottom: 8, border: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 24, background: 'var(--bg4)', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: 'var(--accent)' }}>
                    {c.brand.toUpperCase().slice(0, 4)}
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>•••• •••• •••• {c.last4}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)' }}>{c.name} · Expires {c.expiry}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {c.isDefault
                    ? <span className="badge badge-qualified">Default</span>
                    : <button className="btn btn-ghost btn-xs" onClick={() => setDefaultCard(c.id)}>Set default</button>
                  }
                  {cards.length > 1 && (
                    <button className="btn btn-danger btn-xs" onClick={() => removeCard(c.id)}>✕</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Upgrade Plan Modal */}
      <Modal
        open={Boolean(showPlanModal)}
        onClose={() => setShowPlanModal(null)}
        title={`Upgrade to ${showPlanModal}`}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowPlanModal(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={() => { setPlan(showPlanModal); setSubStatus('Active'); setShowPlanModal(null); toast(`Upgraded to ${showPlanModal}!`); }}>
              Confirm Upgrade
            </button>
          </>
        }
      >
        <p style={{ fontSize: 13, color: 'var(--text2)' }}>
          You're about to upgrade from <strong>{plan}</strong> to <strong>{showPlanModal}</strong>.
          Your billing will be prorated for the current cycle.
        </p>
      </Modal>

      {/* Cancel Modal */}
      <Modal
        open={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        title="Cancel Subscription"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowCancelModal(false)}>Keep subscription</button>
            <button className="btn btn-danger" onClick={() => { setSubStatus('Cancelled'); setShowCancelModal(false); toast('Subscription cancelled', 'info'); }}>
              Yes, cancel
            </button>
          </>
        }
      >
        <p style={{ fontSize: 13, color: 'var(--text2)' }}>
          Are you sure you want to cancel? You'll retain access until the end of your billing period and can reactivate at any time.
        </p>
      </Modal>

      {/* Add Card Modal */}
      <Modal
        open={showAddCard}
        onClose={() => { setShowAddCard(false); setCardErrors({}); }}
        title="Add Payment Method"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowAddCard(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addCard}>Add Card</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Card Number</label>
          <input className="form-input" placeholder="1234 5678 9012 3456" maxLength={19} value={newCard.number} onChange={(e) => { setNewCard((prev) => ({ ...prev, number: formatCardNum(e.target.value) })); setCardErrors((prev) => ({ ...prev, number: undefined })); }} />
          {cardErrors.number && <div className="form-error">{cardErrors.number}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Cardholder Name</label>
          <input className="form-input" placeholder="Alex Morgan" value={newCard.name} onChange={updateCard('name')} />
          {cardErrors.name && <div className="form-error">{cardErrors.name}</div>}
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Expiry (MM/YY)</label>
            <input className="form-input" placeholder="12/27" maxLength={5} value={newCard.expiry} onChange={updateCard('expiry')} />
            {cardErrors.expiry && <div className="form-error">{cardErrors.expiry}</div>}
          </div>
          <div className="form-group">
            <label className="form-label">CVC</label>
            <input className="form-input" placeholder="123" maxLength={4} type="password" value={newCard.cvc} onChange={updateCard('cvc')} />
            {cardErrors.cvc && <div className="form-error">{cardErrors.cvc}</div>}
          </div>
        </div>
      </Modal>
    </div>
  );
}
