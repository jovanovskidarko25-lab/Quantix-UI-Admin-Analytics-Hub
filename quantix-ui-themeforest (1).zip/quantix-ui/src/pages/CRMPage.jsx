import { useState } from 'react';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import { initialLeads, formatCurrency, generateId } from '../data/mockData';

function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Required';
  if (!form.company.trim()) errors.company = 'Required';
  if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) errors.email = 'Valid email required';
  if (!form.value || isNaN(+form.value) || +form.value <= 0) errors.value = 'Enter a valid number';
  return errors;
}

const PER_PAGE = 5;
const STATUSES = ['All', 'Hot', 'Warm', 'Cold', 'Qualified'];

export default function CRMPage({ toast }) {
  const [leads, setLeads] = useState(initialLeads);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [sort, setSort] = useState({ key: 'date', dir: -1 });
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', company: '', email: '', status: 'Hot', value: '' });
  const [errors, setErrors] = useState({});

  const update = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const addLead = () => {
    const errs = validate(form);
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLeads((prev) => [
      ...prev,
      { id: generateId(), ...form, value: +form.value, date: new Date().toISOString().slice(0, 10) },
    ]);
    setShowModal(false);
    setForm({ name: '', company: '', email: '', status: 'Hot', value: '' });
    setErrors({});
    toast('Lead added!');
  };

  const deleteLead = (id) => {
    setLeads((prev) => prev.filter((l) => l.id !== id));
    toast('Lead deleted', 'info');
  };

  const exportCSV = () => {
    const rows = [['Name', 'Company', 'Email', 'Status', 'Value', 'Date'], ...leads.map((l) => [l.name, l.company, l.email, l.status, l.value, l.date])];
    const csv = rows.map((r) => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'leads.csv';
    a.click();
    toast('CSV exported!');
  };

  const setS = (key) => setSort((prev) => ({ key, dir: prev.key === key ? -prev.dir : 1 }));

  const filtered = leads
    .filter((l) => (filter === 'All' || l.status === filter) && (l.name + l.company + l.email).toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => sort.dir * (String(a[sort.key]) > String(b[sort.key]) ? 1 : -1));

  const pages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">CRM</div>
          <div className="page-subtitle">{leads.length} total leads</div>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={exportCSV}>⬇️ Export CSV</button>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Lead</button>
        </div>
      </div>

      <div className="card">
        <div className="flex gap-3 mb-3" style={{ flexWrap: 'wrap' }}>
          <input
            className="form-input"
            style={{ maxWidth: 240 }}
            placeholder="🔍 Search leads…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          />
          <div className="toggle-group">
            {STATUSES.map((s) => (
              <div key={s} className={`toggle-btn${filter === s ? ' active' : ''}`} onClick={() => { setFilter(s); setPage(1); }}>{s}</div>
            ))}
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {[['name', 'Name'], ['company', 'Company'], ['status', 'Status'], ['value', 'Value'], ['date', 'Date']].map(([k, l]) => (
                  <th key={k} className="sortable" onClick={() => setS(k)}>
                    {l} {sort.key === k ? (sort.dir === 1 ? '↑' : '↓') : ''}
                  </th>
                ))}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text3)', padding: 32 }}>No leads found</td></tr>
              ) : paged.map((l) => (
                <tr key={l.id}>
                  <td>
                    <div style={{ fontWeight: 600 }}>{l.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)' }}>{l.email}</div>
                  </td>
                  <td>{l.company}</td>
                  <td><Badge variant={l.status.toLowerCase()}>{l.status}</Badge></td>
                  <td style={{ fontWeight: 600 }}>{formatCurrency(l.value)}</td>
                  <td className="text-sm text-muted">{l.date}</td>
                  <td>
                    <button className="btn btn-danger btn-xs" onClick={() => deleteLead(l.id)}>✕</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {pages > 1 && (
          <div className="flex items-center justify-between mt-3" style={{ paddingTop: 12, borderTop: '1px solid var(--border)' }}>
            <span className="text-sm text-muted">Page {page} of {pages}</span>
            <div className="flex gap-2">
              <button className="btn btn-secondary btn-sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>← Prev</button>
              <button className="btn btn-secondary btn-sm" disabled={page === pages} onClick={() => setPage((p) => p + 1)}>Next →</button>
            </div>
          </div>
        )}
      </div>

      <Modal
        open={showModal}
        onClose={() => { setShowModal(false); setErrors({}); }}
        title="Add New Lead"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addLead}>Add Lead</button>
          </>
        }
      >
        {[
          { field: 'name', label: 'Full Name', type: 'text', ph: 'Alex Morgan' },
          { field: 'company', label: 'Company', type: 'text', ph: 'Acme Corp' },
          { field: 'email', label: 'Email', type: 'email', ph: 'alex@acme.com' },
          { field: 'value', label: 'Deal Value ($)', type: 'number', ph: '25000' },
        ].map(({ field, label, type, ph }) => (
          <div className="form-group" key={field}>
            <label className="form-label">{label}</label>
            <input className="form-input" type={type} placeholder={ph} value={form[field]} onChange={update(field)} />
            {errors[field] && <div className="form-error">{errors[field]}</div>}
          </div>
        ))}
        <div className="form-group">
          <label className="form-label">Status</label>
          <select className="form-input form-select" value={form.status} onChange={update('status')}>
            {['Hot', 'Warm', 'Cold', 'Qualified'].map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      </Modal>
    </div>
  );
}
