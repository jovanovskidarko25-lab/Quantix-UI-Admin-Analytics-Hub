import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    setLoading(false);
    setSent(true);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="brand-icon">✦</div>
          <div className="brand-name">Quantix UI</div>
        </div>

        <div className="auth-title">Reset password</div>
        <div className="auth-subtitle">We'll send a reset link to your inbox</div>

        {sent ? (
          <>
            <div className="auth-alert auth-alert-success">
              Reset link sent to <strong>{email}</strong>. Check your inbox.
            </div>
            <Link to="/login" className="btn btn-secondary w-full" style={{ justifyContent: 'center' }}>
              ← Back to login
            </Link>
          </>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label" htmlFor="email">Email address</label>
              <input
                id="email"
                className="form-input"
                type="email"
                placeholder="admin@quantix.io"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
              />
            </div>

            <button
              className="btn btn-primary w-full"
              onClick={handleSubmit}
              disabled={loading || !email}
              style={{ justifyContent: 'center', height: 40 }}
            >
              {loading ? 'Sending…' : 'Send reset link'}
            </button>
          </>
        )}

        <div className="text-sm" style={{ marginTop: 16, textAlign: 'center', color: 'var(--text2)' }}>
          <Link to="/login" className="auth-link">← Back to login</Link>
        </div>
      </div>
    </div>
  );
}
