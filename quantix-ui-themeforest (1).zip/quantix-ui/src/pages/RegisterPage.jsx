import { useState } from 'react';
import { Link } from 'react-router-dom';

function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Full name is required';
  if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) errors.email = 'Valid email required';
  if (!form.password || form.password.length < 6) errors.password = 'Minimum 6 characters';
  if (form.password !== form.confirm) errors.confirm = "Passwords don't match";
  return errors;
}

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const update = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = () => {
    const errs = validate(form);
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setSuccess(true);
  };

  if (success) return (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🎉</div>
        <div className="auth-title">Account created!</div>
        <div className="auth-subtitle" style={{ marginBottom: 20 }}>Your account is ready to use.</div>
        <Link to="/login" className="btn btn-primary w-full" style={{ justifyContent: 'center' }}>
          Go to login
        </Link>
      </div>
    </div>
  );

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="brand-icon">✦</div>
          <div className="brand-name">Quantix UI</div>
        </div>

        <div className="auth-title">Create account</div>
        <div className="auth-subtitle">Start your 14-day free trial</div>

        {[
          { field: 'name', label: 'Full Name', type: 'text', placeholder: 'Alex Morgan' },
          { field: 'email', label: 'Email', type: 'email', placeholder: 'you@company.com' },
          { field: 'password', label: 'Password', type: 'password', placeholder: '••••••••' },
          { field: 'confirm', label: 'Confirm Password', type: 'password', placeholder: '••••••••' },
        ].map(({ field, label, type, placeholder }) => (
          <div className="form-group" key={field}>
            <label className="form-label" htmlFor={field}>{label}</label>
            <input
              id={field}
              className="form-input"
              type={type}
              placeholder={placeholder}
              value={form[field]}
              onChange={update(field)}
            />
            {errors[field] && <div className="form-error">{errors[field]}</div>}
          </div>
        ))}

        <button
          className="btn btn-primary w-full"
          onClick={handleSubmit}
          style={{ justifyContent: 'center', height: 40 }}
        >
          Create account
        </button>

        <div className="auth-divider">or</div>
        <div className="text-sm" style={{ textAlign: 'center', color: 'var(--text2)' }}>
          Already have an account? <Link to="/login" className="auth-link">Sign in</Link>
        </div>
      </div>
    </div>
  );
}
