import { useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import KPICard from '../components/ui/KPICard';
import ChartCard from '../components/charts/ChartCard';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import { aiUsageData, pieData, formatNumber } from '../data/mockData';

const kpis = [
  { label: 'Total Revenue', value: '$284K', change: '+18.2%', trend: 'up', icon: '💰', accent: 'purple' },
  { label: 'Active Users', value: '42,891', change: '+11.7%', trend: 'up', icon: '👥', accent: 'green' },
  { label: 'AI Queries / Day', value: '18,240', change: '+34.1%', trend: 'up', icon: '🤖', accent: 'cyan' },
  { label: 'Churn Rate', value: '2.8%', change: '-1.4%', trend: 'up', icon: '📉', accent: 'orange' },
];

const allActivity = [
  { action: 'New enterprise lead', user: 'Sarah Chen', time: '2 min ago', status: 'Lead' },
  { action: 'Payment received', user: 'Meridian Labs', time: '18 min ago', status: 'Payment' },
  { action: 'AI model deployed', user: 'System', time: '1h ago', status: 'Deploy' },
  { action: 'Support ticket closed', user: 'Marcus R.', time: '2h ago', status: 'Support' },
  { action: 'New user registered', user: 'Priya Nair', time: '3h ago', status: 'User' },
  { action: 'Invoice paid', user: 'Cobalt Tech', time: '4h ago', status: 'Payment' },
  { action: 'API key generated', user: 'Dev Team', time: '5h ago', status: 'Deploy' },
  { action: 'Report exported', user: 'Alex Morgan', time: '6h ago', status: 'Report' },
  { action: 'New lead qualified', user: 'Tom Nakamura', time: '8h ago', status: 'Lead' },
  { action: 'Subscription upgraded', user: 'Neon Digital', time: '10h ago', status: 'Payment' },
];

export default function DashboardPage({ toast }) {
  const [showAll, setShowAll] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportForm, setReportForm] = useState({ name: '', type: 'Revenue', range: 'Last 30 days', format: 'PDF' });
  const [reportDone, setReportDone] = useState(false);

  const update = (field) => (e) => setReportForm((prev) => ({ ...prev, [field]: e.target.value }));

  const submitReport = () => {
    if (!reportForm.name.trim()) return;
    setReportDone(true);
    setTimeout(() => {
      setReportDone(false);
      setShowReport(false);
      setReportForm({ name: '', type: 'Revenue', range: 'Last 30 days', format: 'PDF' });
      toast('Report queued for generation!');
    }, 1200);
  };

  const activity = showAll ? allActivity : allActivity.slice(0, 5);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">AI Dashboard</div>
          <div className="page-subtitle">Welcome back, Alex 👋 Here's what's happening today.</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowReport(true)}>+ New Report</button>
      </div>

      {/* KPI Cards */}
      <div className="grid-4 section-gap">
        {kpis.map((k) => <KPICard key={k.label} {...k} />)}
      </div>

      {/* Charts */}
      <div className="grid-2 section-gap">
        <ChartCard title="AI Usage Trend" action={<span className="badge badge-live">Live</span>} height={220}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={aiUsageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="week" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={formatNumber} />
              <Tooltip contentStyle={{ background: 'var(--bg2)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} />
              <Line type="monotone" dataKey="queries" stroke="var(--accent)" strokeWidth={2} dot={false} name="Queries" />
              <Line type="monotone" dataKey="tokens" stroke="var(--accent2)" strokeWidth={2} dot={false} name="Tokens" />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="card">
          <div className="card-title mb-3">Plan Distribution</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                  {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1 }}>
              {pieData.map((d) => (
                <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: d.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 12, flex: 1 }}>{d.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 700 }}>{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Activity Table */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <div className="card-title">Recent Activity</div>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowAll((v) => !v)}>
            {showAll ? 'Show less ↑' : 'View all ↓'}
          </button>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Action</th>
                <th>User / Source</th>
                <th>Time</th>
                <th>Type</th>
              </tr>
            </thead>
            <tbody>
              {activity.map((a, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 500 }}>{a.action}</td>
                  <td className="text-muted">{a.user}</td>
                  <td className="text-dim text-sm">{a.time}</td>
                  <td><Badge variant="medium">{a.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Report Modal */}
      <Modal
        open={showReport}
        onClose={() => { setShowReport(false); setReportDone(false); }}
        title="📊 Create New Report"
        footer={!reportDone && (
          <>
            <button className="btn btn-secondary" onClick={() => setShowReport(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={submitReport} disabled={!reportForm.name.trim()}>
              Generate Report
            </button>
          </>
        )}
      >
        {reportDone ? (
          <div style={{ textAlign: 'center', padding: '24px 0' }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>✅</div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Report created!</div>
            <div style={{ color: 'var(--text3)', fontSize: 13, marginTop: 4 }}>
              "{reportForm.name}" is queued for generation.
            </div>
          </div>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label">Report Name *</label>
              <input className="form-input" placeholder="e.g. Q3 Revenue Summary" value={reportForm.name} onChange={update('name')} />
            </div>
            <div className="form-group">
              <label className="form-label">Report Type</label>
              <select className="form-input form-select" value={reportForm.type} onChange={update('type')}>
                {['Revenue', 'User Growth', 'AI Usage', 'Traffic', 'Churn Analysis', 'Invoice Summary'].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Date Range</label>
              <select className="form-input form-select" value={reportForm.range} onChange={update('range')}>
                {['Last 7 days', 'Last 30 days', 'Last 90 days', 'This year'].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Export Format</label>
              <div className="flex gap-2">
                {['PDF', 'CSV', 'Excel'].map((f) => (
                  <div
                    key={f}
                    onClick={() => setReportForm((prev) => ({ ...prev, format: f }))}
                    style={{
                      flex: 1, padding: 8, textAlign: 'center', borderRadius: 8, cursor: 'pointer',
                      border: `2px solid ${reportForm.format === f ? 'var(--accent)' : 'var(--border)'}`,
                      background: reportForm.format === f ? 'var(--glow)' : 'var(--bg3)',
                      color: reportForm.format === f ? 'var(--accent)' : 'var(--text2)',
                      fontSize: 13, fontWeight: 600,
                    }}
                  >
                    {f === 'PDF' ? '📄' : f === 'CSV' ? '📋' : '📊'} {f}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}
