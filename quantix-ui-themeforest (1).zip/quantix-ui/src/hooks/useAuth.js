import { useState, useCallback } from 'react';
import { MOCK_USER } from '../data/mockData';

const SESSION_KEY = 'qx_session';

/**
 * useAuth – handles mock authentication with localStorage persistence.
 * In a real project, replace the login logic with an API call.
 */
export function useAuth() {
  const [session, setSession] = useState(() => {
    try {
      const stored = localStorage.getItem(SESSION_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const login = useCallback(async (email, password) => {
    setLoading(true);
    setError('');

    // Simulate async auth request
    await new Promise((resolve) => setTimeout(resolve, 800));

    if (email === MOCK_USER.email && password === MOCK_USER.password) {
      const newSession = {
        email: MOCK_USER.email,
        name: MOCK_USER.name,
        role: MOCK_USER.role,
        company: MOCK_USER.company,
        initials: MOCK_USER.initials,
        loggedInAt: new Date().toISOString(),
      };
      localStorage.setItem(SESSION_KEY, JSON.stringify(newSession));
      setSession(newSession);
      setLoading(false);
      return { success: true };
    }

    setError('Invalid email or password.');
    setLoading(false);
    return { success: false };
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(SESSION_KEY);
    setSession(null);
  }, []);

  const isAuthenticated = Boolean(session);

  return {
    session,
    isAuthenticated,
    loading,
    error,
    setError,
    login,
    logout,
  };
}
