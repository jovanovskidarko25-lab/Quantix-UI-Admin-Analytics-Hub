import { useState, useCallback } from 'react';
import { generateId } from '../data/mockData';

/**
 * useToast – lightweight toast notification system.
 *
 * Usage:
 *   const { toasts, toast } = useToast();
 *   toast('Saved!');
 *   toast('Something went wrong', 'error');
 *   toast('Uploading…', 'info', 5000);
 */
export function useToast(defaultDuration = 3500) {
  const [toasts, setToasts] = useState([]);

  const toast = useCallback(
    (message, type = 'success', duration = defaultDuration) => {
      const id = generateId();
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, duration);
    },
    [defaultDuration]
  );

  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return { toasts, toast, dismiss };
}
