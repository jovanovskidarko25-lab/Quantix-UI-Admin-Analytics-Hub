import { useState, useEffect, useCallback } from 'react';

const THEME_KEY = 'qx_theme';

/**
 * useTheme – dark/light mode with localStorage persistence.
 */
export function useTheme() {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem(THEME_KEY) !== 'light';
  });

  useEffect(() => {
    document.documentElement.className = darkMode ? '' : 'light-mode';
    localStorage.setItem(THEME_KEY, darkMode ? 'dark' : 'light');
  }, [darkMode]);

  const toggleTheme = useCallback(() => setDarkMode((v) => !v), []);

  return { darkMode, toggleTheme };
}
