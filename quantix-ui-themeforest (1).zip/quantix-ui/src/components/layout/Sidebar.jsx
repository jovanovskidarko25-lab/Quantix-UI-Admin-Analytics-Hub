import { NavLink, useLocation } from 'react-router-dom';

const navItems = [
  { section: 'Overview' },
  { path: '/dashboard', label: 'AI Dashboard', icon: '🤖' },
  { path: '/analytics', label: 'Analytics', icon: '📊' },
  { section: 'Management' },
  { path: '/crm', label: 'CRM', icon: '👥' },
  { path: '/finance', label: 'Finance', icon: '💰' },
  { path: '/projects', label: 'Projects', icon: '🗂️' },
  { section: 'Tools' },
  { path: '/kanban', label: 'Kanban', icon: '📌' },
  { path: '/calendar', label: 'Calendar', icon: '📅' },
  { path: '/chat', label: 'AI Chat', icon: '💬', badge: 'New' },
  { path: '/email', label: 'Email', icon: '✉️' },
  { section: 'Account' },
  { path: '/settings', label: 'Settings', icon: '⚙️' },
];

/**
 * Sidebar – collapsible navigation sidebar.
 *
 * Props:
 *   collapsed    {boolean}
 *   mobileOpen   {boolean}
 *   unreadEmails {number}
 */
export default function Sidebar({ collapsed, mobileOpen, unreadEmails = 0 }) {
  const location = useLocation();

  return (
    <aside
      className={`sidebar${collapsed ? ' collapsed' : ''}${mobileOpen ? ' mobile-open' : ''}`}
      aria-label="Main navigation"
    >
      {/* Brand */}
      <div className="sidebar-brand">
        <div className="brand-icon" aria-hidden="true">✦</div>
        {!collapsed && (
          <>
            <div>
              <div className="brand-name">Quantix UI</div>
            </div>
            <div className="brand-tag" style={{ marginLeft: 'auto' }}>PRO</div>
          </>
        )}
      </div>

      {/* Nav */}
      <nav className="nav-section" aria-label="Sidebar navigation">
        {navItems.map((item, i) => {
          if (item.section) {
            return collapsed ? null : (
              <div key={i} className="nav-label" aria-hidden="true">{item.section}</div>
            );
          }

          const isActive = location.pathname === item.path ||
            (item.path !== '/dashboard' && location.pathname.startsWith(item.path));

          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`nav-item${isActive ? ' active' : ''}`}
              title={collapsed ? item.label : undefined}
            >
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>
              {!collapsed && (
                <>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {item.path === '/email' && unreadEmails > 0 && (
                    <span className="nav-badge" aria-label={`${unreadEmails} unread`}>{unreadEmails}</span>
                  )}
                  {item.badge && (
                    <span className="nav-badge">{item.badge}</span>
                  )}
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Pro plan indicator */}
      {!collapsed && (
        <div style={{ padding: '12px', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
          <div style={{ background: 'var(--glow)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 'var(--radius)', padding: '10px 12px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', marginBottom: 4 }}>✨ Pro Plan Active</div>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8 }}>82% of storage used</div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: '82%' }} />
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
