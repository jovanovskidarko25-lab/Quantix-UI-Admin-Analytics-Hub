import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';

/**
 * AppLayout – shell that wraps all authenticated pages.
 * Manages sidebar collapse state and wires up header actions.
 *
 * Props:
 *   darkMode        {boolean}
 *   onToggleTheme   {function}
 *   onLogout        {function}
 *   notifications   {Array}
 *   onMarkRead      {function}
 *   onMarkAllRead   {function}
 *   session         {object}
 *   unreadEmails    {number}
 */
export default function AppLayout({
  darkMode,
  onToggleTheme,
  onLogout,
  notifications,
  onMarkRead,
  onMarkAllRead,
  session,
  unreadEmails,
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleMenuToggle = () => {
    if (window.innerWidth <= 768) {
      setMobileOpen((v) => !v);
    } else {
      setCollapsed((v) => !v);
    }
  };

  return (
    <div className="app-shell">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="mobile-overlay" onClick={() => setMobileOpen(false)} aria-hidden="true" />
      )}

      <Sidebar
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        unreadEmails={unreadEmails}
      />

      <main className={`main-area${collapsed ? ' collapsed' : ''}`}>
        <Header
          onMenuToggle={handleMenuToggle}
          darkMode={darkMode}
          onToggleTheme={onToggleTheme}
          onLogout={onLogout}
          notifications={notifications}
          onMarkRead={onMarkRead}
          onMarkAllRead={onMarkAllRead}
          session={session}
        />
        <div className="page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
