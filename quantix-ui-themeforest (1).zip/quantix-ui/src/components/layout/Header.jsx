import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const pageTitles = {
  '/dashboard': 'AI Dashboard',
  '/analytics': 'Analytics',
  '/crm': 'CRM',
  '/finance': 'Finance',
  '/projects': 'Projects',
  '/kanban': 'Kanban',
  '/calendar': 'Calendar',
  '/chat': 'AI Chat',
  '/email': 'Email',
  '/settings': 'Settings',
};

/**
 * Header – sticky top header with search, theme toggle, notifications and profile.
 *
 * Props:
 *   onMenuToggle    {function}
 *   darkMode        {boolean}
 *   onToggleTheme   {function}
 *   onLogout        {function}
 *   notifications   {Array}
 *   onMarkRead      {function(id)}
 *   onMarkAllRead   {function}
 *   session         {object}
 */
export default function Header({
  onMenuToggle,
  darkMode,
  onToggleTheme,
  onLogout,
  notifications,
  onMarkRead,
  onMarkAllRead,
  session,
}) {
  const [showNotif, setShowNotif] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const notifRef = useRef(null);
  const profileRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();

  const unread = notifications.filter((n) => !n.read).length;
  const pageTitle = pageTitles[location.pathname] ?? 'Dashboard';

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setShowNotif(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setShowProfile(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <header className="header">
      <button className="h-btn" onClick={onMenuToggle} aria-label="Toggle sidebar" title="Toggle sidebar">
        ☰
      </button>

      <div style={{ fontWeight: 700, fontSize: 15 }}>{pageTitle}</div>

      <div className="header-spacer" />

      {/* Search */}
      <div className="header-search hide-mobile">
        <span className="header-search-icon" aria-hidden="true">🔍</span>
        <input placeholder="Search anything…" aria-label="Search" />
      </div>

      {/* Theme toggle */}
      <button className="h-btn" onClick={onToggleTheme} aria-label="Toggle theme" title="Toggle theme">
        {darkMode ? '☀️' : '🌙'}
      </button>

      {/* Notifications */}
      <div className="relative" ref={notifRef}>
        <button
          className="h-btn"
          onClick={() => { setShowNotif((v) => !v); setShowProfile(false); }}
          aria-label={`Notifications${unread > 0 ? `, ${unread} unread` : ''}`}
        >
          🔔
          {unread > 0 && <span className="badge-count" aria-hidden="true">{unread}</span>}
        </button>

        {showNotif && (
          <div className="dropdown" style={{ width: 320 }} role="menu">
            <div className="dropdown-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div className="dropdown-name">Notifications</div>
                <div className="dropdown-email">{unread} unread</div>
              </div>
              {unread > 0 && (
                <button className="btn btn-ghost btn-sm" onClick={onMarkAllRead}>Mark all read</button>
              )}
            </div>

            {notifications.map((n) => (
              <div
                key={n.id}
                className={`notif-item${n.read ? '' : ' unread'}`}
                onClick={() => onMarkRead(n.id)}
                role="menuitem"
              >
                <span className="notif-icon" aria-hidden="true">{n.icon}</span>
                <div style={{ flex: 1 }}>
                  <div className="notif-text">{n.text}</div>
                  <div className="notif-time">{n.time}</div>
                </div>
                {!n.read && <div className="notif-unread-dot" aria-hidden="true" />}
              </div>
            ))}

            <div
              style={{ padding: '10px 14px', textAlign: 'center', fontSize: 12, color: 'var(--accent)', cursor: 'pointer' }}
              onClick={() => setShowNotif(false)}
              role="menuitem"
            >
              View all notifications
            </div>
          </div>
        )}
      </div>

      {/* Profile */}
      <div className="relative" ref={profileRef}>
        <div
          className="user-avatar"
          onClick={() => { setShowProfile((v) => !v); setShowNotif(false); }}
          role="button"
          aria-label="Profile menu"
          tabIndex={0}
        >
          {session?.initials ?? 'AM'}
        </div>

        {showProfile && (
          <div className="dropdown" role="menu">
            <div className="dropdown-header">
              <div className="dropdown-name">{session?.name ?? 'Alex Morgan'}</div>
              <div className="dropdown-email">{session?.email ?? 'admin@quantix.io'}</div>
            </div>
            <div className="dropdown-item" role="menuitem" onClick={() => { navigate('/settings'); setShowProfile(false); }}>
              ⚙️ Profile Settings
            </div>
            <div className="dropdown-item" role="menuitem" onClick={() => { navigate('/settings?tab=billing'); setShowProfile(false); }}>
              💳 Billing
            </div>
            <hr className="dropdown-divider" />
            <div className="dropdown-item danger" role="menuitem" onClick={onLogout}>
              🚪 Sign out
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
