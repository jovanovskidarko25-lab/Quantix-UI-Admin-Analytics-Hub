/**
 * ChartCard – wrapper card for Recharts charts with title, subtitle and optional action slot.
 *
 * Props:
 *   title    {string}
 *   subtitle {string}
 *   action   {node}   – optional right-side element (toggles, buttons, etc.)
 *   height   {number} – chart area height in px, default 240
 *   children {node}   – Recharts ResponsiveContainer + chart
 */
export default function ChartCard({ title, subtitle, action, height = 240, children }) {
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <div>
          {title && <div className="card-title">{title}</div>}
          {subtitle && <div className="card-sub">{subtitle}</div>}
        </div>
        {action && <div>{action}</div>}
      </div>
      <div style={{ height }}>{children}</div>
    </div>
  );
}
