/**
 * ToastContainer – renders active toast notifications.
 * Pair with the useToast() hook.
 *
 * Props:
 *   toasts   {Array<{id, message, type}>}
 *   dismiss  {function(id)}
 */

const icons = {
  success: '✅',
  error: '❌',
  info: 'ℹ️',
  warning: '⚠️',
};

export default function ToastContainer({ toasts, dismiss }) {
  if (!toasts.length) return null;

  return (
    <div className="toast-container" role="region" aria-label="Notifications">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`toast toast-${t.type}`}
          role="alert"
          onClick={() => dismiss(t.id)}
          style={{ cursor: 'pointer' }}
        >
          <span aria-hidden="true">{icons[t.type] ?? icons.info}</span>
          <span style={{ flex: 1 }}>{t.message}</span>
          <button
            className="btn btn-ghost btn-icon"
            style={{ width: 20, height: 20, fontSize: 11, opacity: 0.6 }}
            onClick={() => dismiss(t.id)}
            aria-label="Dismiss"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
