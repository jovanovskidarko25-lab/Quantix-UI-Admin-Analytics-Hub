/**
 * KPICard – reusable metric card with icon, value, label and trend indicator.
 *
 * Props:
 *   label    {string}  – metric name
 *   value    {string}  – formatted metric value
 *   change   {string}  – e.g. "+18.2%"
 *   trend    {'up'|'down'|'neutral'} – controls color of change indicator
 *   icon     {string}  – emoji or character
 *   accent   {'purple'|'green'|'cyan'|'orange'} – decorative accent color
 */

const accentStyles = {
  purple: { bg: 'rgba(99,102,241,0.08)', circle: '#6366f1' },
  green:  { bg: 'rgba(16,185,129,0.08)',  circle: '#10b981' },
  cyan:   { bg: 'rgba(6,182,212,0.08)',   circle: '#06b6d4' },
  orange: { bg: 'rgba(245,158,11,0.08)',  circle: '#f59e0b' },
};

export default function KPICard({ label, value, change, trend = 'up', icon, accent = 'purple' }) {
  const { bg, circle } = accentStyles[accent] || accentStyles.purple;
  const trendColor = trend === 'up' ? 'var(--green)' : trend === 'down' ? 'var(--red)' : 'var(--text3)';
  const trendArrow = trend === 'up' ? '▲' : trend === 'down' ? '▼' : '●';

  return (
    <div
      style={{
        background: 'var(--bg2)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: '18px 20px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Decorative background circle */}
      <div
        aria-hidden="true"
        style={{
          position: 'absolute',
          top: -20,
          right: -20,
          width: 80,
          height: 80,
          borderRadius: '50%',
          background: circle,
          opacity: 0.12,
        }}
      />

      {/* Icon */}
      {icon && (
        <div style={{ position: 'absolute', top: 16, right: 16, fontSize: 22, opacity: 0.6 }}>
          {icon}
        </div>
      )}

      {/* Label */}
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text3)', letterSpacing: '0.5px', textTransform: 'uppercase' }}>
        {label}
      </div>

      {/* Value */}
      <div style={{ fontSize: 26, fontWeight: 800, margin: '6px 0 4px', letterSpacing: '-0.5px' }}>
        {value}
      </div>

      {/* Change */}
      {change && (
        <div style={{ fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4, color: trendColor }}>
          <span>{trendArrow}</span>
          <span>{change} vs last month</span>
        </div>
      )}
    </div>
  );
}
