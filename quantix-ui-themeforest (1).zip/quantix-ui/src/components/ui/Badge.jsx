/**
 * Badge – reusable status/label badge.
 *
 * Props:
 *   variant  {string} – maps to CSS class, e.g. 'hot', 'qualified', 'in-progress'
 *   children {node}
 */
export default function Badge({ variant = 'medium', children, style }) {
  return (
    <span className={`badge badge-${variant}`} style={style}>
      {children}
    </span>
  );
}
