import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// Hooks
import { useAuth } from './hooks/useAuth';
import { useTheme } from './hooks/useTheme';
import { useToast } from './hooks/useToast';

// Layout
import AppLayout from './components/layout/AppLayout';
import { ProtectedRoute, PublicRoute } from './router/guards';

// UI
import ToastContainer from './components/ui/ToastContainer';

// Auth Pages
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';

// Dashboard Pages
import DashboardPage from './pages/DashboardPage';
import AnalyticsPage from './pages/AnalyticsPage';
import CRMPage from './pages/CRMPage';
import FinancePage from './pages/FinancePage';
import ProjectsPage from './pages/ProjectsPage';
import KanbanPage from './pages/KanbanPage';
import CalendarPage from './pages/CalendarPage';
import ChatPage from './pages/ChatPage';
import EmailPage from './pages/EmailPage';
import SettingsPage from './pages/SettingsPage';

// Data
import { initialNotifications } from './data/mockData';

/**
 * App – root component.
 * Wires together routing, auth, theme, toasts, and global state.
 */
export default function App() {
  const { session, isAuthenticated, login, logout } = useAuth();
  const { darkMode, toggleTheme } = useTheme();
  const { toasts, toast, dismiss } = useToast();

  const [notifications, setNotifications] = useState(initialNotifications);

  const markRead = (id) => setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
  const markAllRead = () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));

  const unreadEmails = 2; // In a real app, derive from email state

  return (
    <BrowserRouter>
      <Routes>
        {/* ─── Public Routes ─── */}
        <Route element={<PublicRoute />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        </Route>

        {/* ─── Protected Routes ─── */}
        <Route
          element={
            <ProtectedRoute />
          }
        >
          <Route
            element={
              <AppLayout
                darkMode={darkMode}
                onToggleTheme={toggleTheme}
                onLogout={logout}
                notifications={notifications}
                onMarkRead={markRead}
                onMarkAllRead={markAllRead}
                session={session}
                unreadEmails={unreadEmails}
              />
            }
          >
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<DashboardPage toast={toast} />} />
            <Route path="/analytics" element={<AnalyticsPage toast={toast} />} />
            <Route path="/crm" element={<CRMPage toast={toast} />} />
            <Route path="/finance" element={<FinancePage toast={toast} />} />
            <Route path="/projects" element={<ProjectsPage toast={toast} />} />
            <Route path="/kanban" element={<KanbanPage toast={toast} />} />
            <Route path="/calendar" element={<CalendarPage toast={toast} />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/email" element={<EmailPage toast={toast} />} />
            <Route path="/settings" element={<SettingsPage toast={toast} />} />
          </Route>
        </Route>

        {/* ─── Fallback ─── */}
        <Route path="*" element={<Navigate to={isAuthenticated ? '/dashboard' : '/login'} replace />} />
      </Routes>

      <ToastContainer toasts={toasts} dismiss={dismiss} />
    </BrowserRouter>
  );
}
